package sharker.Ovi;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class Delete extends AppCompatActivity implements OnClickListener,
		OnCheckedChangeListener {

	// views
	private Button delButton;
	private ListView list;

	private Dialog dialogAreYouSure;
	private Button yes, no;

	// logics

	private String[] titles = getApplicationContext().getFilesDir().list();
	private String[] colorList;
	private String[] dates;
	private boolean[] checked;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.delete);

		// initializing
		this.list = (ListView) findViewById(R.id.listView_delete);
		this.delButton = (Button) findViewById(R.id.deleteButton);

		this.dialogAreYouSure = new Dialog(this);
		this.dialogAreYouSure.setContentView(R.layout.dialog_are_you_sure);
		this.yes = (Button) this.dialogAreYouSure
				.findViewById(R.id.yes_are_u_sure_dialog);
		this.no = (Button) this.dialogAreYouSure
				.findViewById(R.id.no_are_u_sure_dialog);

		// construct dates
		this.dates = NoteManager.ConstructDates(getApplicationContext());
		this.colorList = NoteManager.ConstructColors(getApplicationContext());
		this.checked = new boolean[this.dates.length];

		// set notes list
		String[] fileList = this.titles == null ? new String[0] : this.titles;
		this.list.setAdapter(new MyAdapterDelete(this,
				android.R.layout.simple_list_item_1, R.id.title_delete_row,
				fileList, this.dates, this.colorList));
		this.delButton.setEnabled(false);
		for (int i = 0; i < checked.length; i++) {
			this.checked[i] = false;
		}

		// listener
		this.delButton.setOnClickListener(this);
		this.yes.setOnClickListener(this);
		this.no.setOnClickListener(this);

	}

	// internal class
	private class MyAdapterDelete extends ArrayAdapter<String> {

		private String[] noteList, dateList, colorList;

		public MyAdapterDelete(Context context, int resource,
				int textViewResourceId, String[] titles, String[] dates,
				String[] colors) {
			super(context, resource, textViewResourceId, titles);

			this.noteList = titles;
			this.dateList = dates;
			this.colorList = colors;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			// initialize
			LayoutInflater inflater = getLayoutInflater();
			View row = inflater.inflate(R.layout.delete_row, parent, false);

			TextView title = (TextView) row.findViewById(R.id.title_delete_row);
			TextView date = (TextView) row.findViewById(R.id.date_delete_row);
			RelativeLayout layout = (RelativeLayout) row
					.findViewById(R.id.Relative_layout);
			CheckBox chBox = (CheckBox) row.findViewById(R.id.checkbox_delete);

			// settings
			title.setText(this.noteList[position]);
			date.setText(this.dateList[position]);
			layout.setBackgroundColor(Color
					.parseColor(this.colorList[position]));

			// listener
			chBox.setOnCheckedChangeListener(Delete.this);

			return row;
		}

	}

	@Override
	public void onClick(View v) {

		if (v.equals(this.delButton)) {
			// delete button pressed
			// simply show dialog box that "are u sure"

			this.dialogAreYouSure.setTitle("Delete Selected notes");
			this.dialogAreYouSure.show();
		} else if (v.equals(this.yes)) {
			// yess button pressed of the dialog
			// simply delete selected & close the dialog & switch back to main
			for (int i = 0; i < this.checked.length; i++) {
				if (this.checked[i]) {
					// delete this note
					NoteManager.RemoveNote(getApplicationContext(), this.titles[i]);
				}
			}
			this.dialogAreYouSure.cancel();
			onBackPressed();
		} else if (v.equals(this.no)) {
			// no burron pressed of the dialog
			// simply close the fucking dialog
			this.dialogAreYouSure.cancel();
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

		RelativeLayout row = (RelativeLayout) buttonView.getParent();

		// setting the boolean array
		for (int i = 0; i < this.list.getChildCount(); i++) {
			if (row.equals(this.list.getChildAt(i))) {
				this.checked[i] = isChecked;
			}
		}

		// now check the boolean value for any true value
		for (int i = 0; i < this.checked.length; i++) {
			if (this.checked[i]) {
				this.delButton.setEnabled(true);
				return;
			}
		}
		this.delButton.setEnabled(false);

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		onCreate(null);
	}
}