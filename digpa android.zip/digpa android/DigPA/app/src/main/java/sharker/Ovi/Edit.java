package sharker.Ovi;

import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

public class Edit extends AppCompatActivity implements OnClickListener,
		OnSeekBarChangeListener {

	private EditText title, content;

	private Dialog dialogAreYouSure, colorChng;
	private Button yes_sure, no_sure, ok_cnhg, cancel_chng;
	private TextView preview_chng;
	private SeekBar bar1, bar2, bar3, bar4;
	private Properties properties;

	private String selectedOptionMenuItem;
	String titleBefore, colorString, caller;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edit);

		this.caller = this.getIntent().getExtras().getString("caller");
		if (caller.compareTo("EDIT") == 0) {
			this.titleBefore = this.getIntent().getExtras().getString("title");
			this.colorString = NoteManager.readColorFromNote(getApplicationContext(), this.titleBefore);
		}

		// initilizing
		this.title = (EditText) findViewById(R.id.title_edit);
		this.content = (EditText) findViewById(R.id.content_edit);

		this.dialogAreYouSure = new Dialog(this);
		this.colorChng = new Dialog(this);

		this.dialogAreYouSure.setContentView(R.layout.dialog_are_you_sure);
		this.colorChng.setContentView(R.layout.dialog_color);

		this.yes_sure = (Button) this.dialogAreYouSure
				.findViewById(R.id.yes_are_u_sure_dialog);
		this.no_sure = (Button) this.dialogAreYouSure
				.findViewById(R.id.no_are_u_sure_dialog);
		this.ok_cnhg = (Button) this.colorChng.findViewById(R.id.ok_chng);
		this.cancel_chng = (Button) this.colorChng
				.findViewById(R.id.cancel_chng);
		this.preview_chng = (TextView) this.colorChng
				.findViewById(R.id.preview_color);
		this.bar1 = (SeekBar) this.colorChng.findViewById(R.id.seekBar1);
		this.bar2 = (SeekBar) this.colorChng.findViewById(R.id.seekBar2);
		this.bar3 = (SeekBar) this.colorChng.findViewById(R.id.seekBar3);
		this.bar4 = (SeekBar) this.colorChng.findViewById(R.id.seekBar4);

		this.properties = new Properties(this);

		if (caller.compareTo("EDIT") == 0) {
			// settings
			this.title.setText(this.titleBefore);
			this.title.setBackgroundColor(Color.parseColor(this.colorString));
			this.content.setText(NoteManager
					.readContentFromNote(getApplicationContext(), this.titleBefore));

		} else if (caller.compareTo("ADD") == 0) {
			// set color to default white
			this.colorString = "#88ffffff";
		}

		// Listener
		this.yes_sure.setOnClickListener(this);
		this.no_sure.setOnClickListener(this);
		this.ok_cnhg.setOnClickListener(this);
		this.cancel_chng.setOnClickListener(this);

		this.bar1.setOnSeekBarChangeListener(this);
		this.bar2.setOnSeekBarChangeListener(this);
		this.bar3.setOnSeekBarChangeListener(this);
		this.bar4.setOnSeekBarChangeListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.edit_option_menu, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub

		if (item.getItemId() == R.id.item_edit_option_1) {
			// chng color
			this.colorChng.setTitle("Background Color");
			if (this.caller.compareTo("EDIT") == 0) {
				// itz called for editing purpose not for creating
				int c = Color.parseColor(this.colorString);
				int alpha = 238 - Color.alpha(c), red = Color.red(c), green = Color
						.green(c), blue = Color.blue(c);

				this.bar1.setProgress(alpha);
				this.bar2.setProgress(red);
				this.bar3.setProgress(green);
				this.bar4.setProgress(blue);
				((TextView) this.colorChng.findViewById(R.id.preview_color))
						.setBackgroundColor(c);

			}
			this.colorChng.show();
		} else if (item.getItemId() == R.id.item_edit_option_2) {
			// save note
			this.selectedOptionMenuItem = "SAVE";
			if (NoteManager.doesThisNoteAlreadyExits(getApplicationContext(), this.title.getText()
					.toString())) {
				// a note already exists on that title
				this.dialogAreYouSure.setTitle("given title exists-overwrite?");
			} else {
				// no note exists on that title
				this.dialogAreYouSure.setTitle("Save this note");
			}
			this.dialogAreYouSure.show();
		} else if (item.getItemId() == R.id.item_edit_option_3) {
			// discard with a dialog
			this.selectedOptionMenuItem = "DISCARD";
			this.dialogAreYouSure.setTitle("Discard this note");
			this.dialogAreYouSure.show();
		} else if (item.getItemId() == R.id.item_edit_option_4) {
			// delete note with a dialog
			this.selectedOptionMenuItem = "DELETE";
			this.dialogAreYouSure.setTitle("Delete this note");
			this.dialogAreYouSure.show();
		} else if (item.getItemId() == R.id.item_edit_option_5) {
			// show properties
			String title = this.titleBefore, colorString = NoteManager
					.readColorFromNote(getApplicationContext(), this.title.getText().toString()), sizeString = NoteManager
					.readSizeFromNote(getApplicationContext(), title), dateString = NoteManager
					.readDateFromNote(getApplicationContext(), title);

			properties.setProperties(this.title.getText().toString(),
					colorString, sizeString, dateString);
			properties.setTitle("Properties - " + title);
			properties.show();
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.equals(this.yes_sure)) {
			// yess pressed
			if (this.selectedOptionMenuItem.compareTo("SAVE") == 0) {
				// simply rename + save & switch to main list
				Log.d("RATUL", this.colorString
						+ this.content.getText().toString());

				if (this.caller.compareTo("EDIT") == 0) {
					NoteManager.renameNote(getApplicationContext(), this.titleBefore, this.title
							.getText().toString());
				}

				NoteManager.overwriteNoteContent(getApplicationContext(), this.title.getText()
						.toString(), this.colorString
						+ this.content.getText().toString());
				this.dialogAreYouSure.cancel();
				super.onBackPressed();
			} else if (this.selectedOptionMenuItem.compareTo("DISCARD") == 0) {
				// simply switch to main list
				this.dialogAreYouSure.cancel();
				super.onBackPressed();
			} else if (this.selectedOptionMenuItem.compareTo("DELETE") == 0) {
				// delete note & switch to main
				NoteManager.RemoveNote(getApplicationContext(), this.titleBefore);
				this.dialogAreYouSure.cancel();
				super.onBackPressed();
			}
		} else if (v.equals(this.no_sure)) {
			// no button pressed
			this.dialogAreYouSure.cancel();
		} else if (v.equals(this.ok_cnhg)) {
			// ok button pressed of the color option
			// simply save the selected color as the colorString
			int alpha = 238 - this.bar1.getProgress() + 17, red = this.bar2
					.getProgress() + 17, green = this.bar3.getProgress() + 17, blue = this.bar4
					.getProgress() + 17;
			this.colorString = "#" + Integer.toHexString(alpha)
					+ Integer.toHexString(red) + Integer.toHexString(green)
					+ Integer.toHexString(blue);
			this.title.setBackgroundColor(Color.parseColor(this.colorString));
			this.colorChng.cancel();
		} else if (v.equals(this.cancel_chng)) {
			this.colorChng.cancel();
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		this.finish();
	}

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress,
			boolean fromUser) {
		// TODO Auto-generated method stub
		int alpha = 238 - this.bar1.getProgress() + 17, red = this.bar2
				.getProgress() + 17, green = this.bar3.getProgress() + 17, blue = this.bar4
				.getProgress() + 17;
		this.preview_chng.setBackgroundColor(Color
				.argb(alpha, red, green, blue));
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub

	}
}
