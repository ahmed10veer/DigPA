package sharker.Ovi;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class Main extends AppCompatActivity implements OnClickListener {

	// logic constraints
	private String[] colorList;
	private String[] dates;

	// view constraints
	private Button add;
	private ListView list;
	private View contextMenuInvoker;

	private Dialog dialogAreYouSure;
	private Button yes, no;

	private Properties properties;

	private MyAdapterMain adapter;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// initializing
		Typeface tf = Typeface.createFromAsset(getAssets(),
				"fonts/Quad Ultra.otf");

		this.list = (ListView) findViewById(R.id.listView_main);
		this.add = (Button) findViewById(R.id.addButton);

		this.dialogAreYouSure = new Dialog(this);
		this.dialogAreYouSure.setContentView(R.layout.dialog_are_you_sure);
		this.yes = (Button) this.dialogAreYouSure
				.findViewById(R.id.yes_are_u_sure_dialog);
		this.no = (Button) this.dialogAreYouSure
				.findViewById(R.id.no_are_u_sure_dialog);

		this.properties = new Properties(this);

		// construct dates
		this.dates = NoteManager.ConstructDates(getApplicationContext());
		this.colorList = NoteManager.ConstructColors(getApplicationContext());

		// set notes list

		adapter = new MyAdapterMain(this,
				android.R.layout.simple_list_item_1,
				R.id.title_main_row,
				NoteManager.getFileList(getApplicationContext()),
				this.dates,
				this.colorList);
		this.list.setAdapter(adapter);
		// this.add.setTypeface(tf);

		// Listener
		this.yes.setOnClickListener(this);
		this.no.setOnClickListener(this);
		this.add.setOnClickListener(this);
	}

	private class MyAdapterMain extends ArrayAdapter<String> {

		private String[] noteList, dateList, colorList;

		public MyAdapterMain(Context context, int resource,
				int textViewResourceId, String[] titles, String[] dates,
				String[] colors) {
			super(context, resource, textViewResourceId, titles);
			// TODO Auto-generated constructor stub

			this.noteList = titles;
			this.dateList = dates;
			this.colorList = colors;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			LayoutInflater inflater = getLayoutInflater();
			View row = inflater.inflate(R.layout.main_row, parent, false);

			TextView title = (TextView) row.findViewById(R.id.title_main_row);
			TextView date = (TextView) row.findViewById(R.id.date_main_row);
			LinearLayout layout = (LinearLayout) row
					.findViewById(R.id.main_row_linear);

			title.setText(this.noteList[position]);
			date.setText(this.dateList[position]);

			layout.setBackgroundColor(Color
					.parseColor(this.colorList[position]));

			Main.this.registerForContextMenu(row);

			return row;
		}

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		// super.onBackPressed();
		this.finish();
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {

		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = this.getMenuInflater();
		inflater.inflate(R.menu.main_context_menu, menu);
		this.contextMenuInvoker = v;
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {

		View row = this.contextMenuInvoker;

		if (item.getItemId() == R.id.item_main_context_1) {
			// view option selected
			if (row != null) {
				TextView title = (TextView) row
						.findViewById(R.id.title_main_row);
				TextView date = (TextView) row.findViewById(R.id.date_main_row);

				Intent intent = new Intent(Main.this, view.class);
				intent.putExtra("title", title.getText().toString());
				intent.putExtra("date", date.getText().toString());

				this.startActivity(intent);
			} else {
				Log.d("RATUL", "NULL is in view");
			}

		} else if (item.getItemId() == R.id.item_main_context_2) {
			// edit option selected
			if (row != null) {
				TextView title = (TextView) row
						.findViewById(R.id.title_main_row);
				Intent intent = new Intent(Main.this, Edit.class);
				intent.putExtra("caller", "EDIT");
				intent.putExtra("title", title.getText().toString());

				this.startActivity(intent);
			}
		} else if (item.getItemId() == R.id.item_main_context_3) {
			// delete option selected -- delete with a dialog
			this.dialogAreYouSure.setTitle("Delete this note");
			this.dialogAreYouSure.show();
		} else if (item.getItemId() == R.id.item_main_context_4) {
			// properties option selected
			TextView titleView = (TextView) row
					.findViewById(R.id.title_main_row);
			String title = titleView.getText().toString(), colorString = NoteManager
					.readColorFromNote(getApplicationContext(), title.toString()), sizeString = NoteManager
					.readSizeFromNote(getApplicationContext(), title), dateString = NoteManager
					.readDateFromNote(getApplicationContext(), title);

			properties
					.setProperties(title, colorString, sizeString, dateString);
			properties.setTitle("Properties - " + title);
			properties.show();
		}
		return super.onContextItemSelected(item);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		boolean val = super.onCreateOptionsMenu(menu);
		;
		MenuInflater mInflater = getMenuInflater();
		mInflater.inflate(R.menu.main_option_menu, menu);

		return val;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		boolean val = super.onOptionsItemSelected(item);

		if (item.getItemId() == R.id.item_main_option_1) {
			// simply goto delete activity
			Intent intent = new Intent(Main.this, Delete.class);
			this.startActivity(intent);
		} else if (item.getItemId() == R.id.item_main_option_2) {
			// show help dialog
			Dialog dialog = new Dialog(this);
			dialog.setTitle("help");
			dialog.setContentView(R.layout.dialog_menu_help);
			dialog.show();
		} else if (item.getItemId() == R.id.item_main_option_3) {
			// show about dialog
			Dialog dialog = new Dialog(this);
			dialog.setTitle("about");
			dialog.setContentView(R.layout.dialog_menu_about);
			dialog.show();
		}
		return val;
	}

	@Override
	public void onClick(View v) {
		View row = this.contextMenuInvoker;

		if (v.equals(this.yes)) {
			// yess pressed for delete option only
			if (row != null) {
				TextView title = (TextView) row
						.findViewById(R.id.title_main_row);
				NoteManager.RemoveNote(getApplicationContext(), title.getText().toString());
				// construct dates
				this.dates = NoteManager.ConstructDates(getApplicationContext());
				this.colorList = NoteManager.ConstructColors(getApplicationContext());
				// set notes list
				this.list.setAdapter(new MyAdapterMain(this,
						android.R.layout.simple_list_item_1,
						R.id.title_main_row, NoteManager.getFileList(getApplicationContext()), this.dates,
						this.colorList));

				this.dialogAreYouSure.cancel();
			}
		} else if (v.equals(this.no)) {
			// no button pressed for delete option only
			this.dialogAreYouSure.cancel();
		} else if (v.equals(this.add)) {
			// add button pressed now switch to edit without any data
			Intent intent = new Intent(Main.this, Edit.class);
			intent.putExtra("caller", "ADD");

			this.startActivity(intent);
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		// NEW THINGS
		this.dates = NoteManager.ConstructDates(getApplicationContext());
		this.colorList = NoteManager.ConstructColors(getApplicationContext());
		// set notes list
		this.list.setAdapter(new MyAdapterMain(this,
				android.R.layout.simple_list_item_1,
				R.id.title_main_row, NoteManager.getFileList(getApplicationContext()), this.dates,
				this.colorList));
	}
}