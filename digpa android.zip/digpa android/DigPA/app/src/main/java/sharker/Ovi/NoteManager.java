package sharker.Ovi;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.util.Log;
import android.content.Context;

/*this class will supply some static method and final values
 * that will help to manage & read note content
 */
public final class NoteManager {

	private static String subDirectory = "/notes/";

	public static String[] getFileList(Context ctx) {
		String[] list = ctx.getFilesDir().list();
		if (list == null) {
			return new String[0];
		} else {
			return list;
		}
	}

	public static String readColorFromNote(Context ctx, String title) {
		try {
			String rootPath = ctx.getFilesDir().getAbsolutePath();
			FileReader reader = new FileReader(rootPath + "/" + title);

			char buf[] = new char[10];

			reader.read(buf);
			String colorString = new String(buf, 0, 9);

			reader.close();
			return colorString;

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static String readContentFromNote(Context ctx, String title) {
		try {
			String rootPath = ctx.getFilesDir().getAbsolutePath();
			FileReader reader = new FileReader(rootPath + "/" + title);
			char buf[] = new char[1024];
			int readen;
			String text = "";
			boolean isFirstTym = true;

			while ((readen = reader.read(buf)) != -1) {

				if (isFirstTym) {
					text += new String(buf, 9, readen - 9);
					isFirstTym = false;
				} else {
					text += new String(buf, 0, readen);
				}

			}
			reader.close();

			return text;

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static String readDateFromNote(Context ctx,String title) {
		String rootPath = ctx.getFilesDir().getAbsolutePath();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy'-'h:mm a");
		File note = new File(ctx + "/" + title);
		return sdf.format(new Date(note.lastModified()));
	}

	public static String readSizeFromNote(Context ctx, String title) {
		String rootPath = ctx.getFilesDir().getAbsolutePath();
		File note = new File(rootPath + "/" + title);
		long size = note.length();
		if (size < 1024) {
			// show size in byte
			return size + " byte";
		} else {
			// show size in Kb
			return size + " Kb";
		}
	}

	public static boolean doesThisNoteAlreadyExits(Context ctx, String title) {
		String rootPath = ctx.getFilesDir().getAbsolutePath();
		File file = new File(rootPath + "/" + title);

		return file.exists();

	}

	public static boolean renameNote(Context ctx, String before, String after) {
		String rootPath = ctx.getFilesDir().getAbsolutePath();
		File file = new File(rootPath + "/" + before);
		return file.renameTo(new File(rootPath + "/" + after));
	}

	public static boolean overwriteNoteContent(Context ctx, String title, String content) {
		String rootPath = ctx.getFilesDir().getAbsolutePath();
		File file = new File(rootPath + "/" + title);
		try {
			file.createNewFile();
			FileWriter writer = new FileWriter(file);
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Log.e("RATUL", "Writing failure" + e.toString());
			return false;
		}
		return true;
	}

	public static String[] ConstructDates(Context ctx) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy 'at' h:mm  a");
		// Log.d("RATUL", sdf.format(new Date(System.currentTimeMillis())));

		File root = ctx.getFilesDir();
		File[] fileList = root.listFiles();
		if (fileList == null) {
			return new String[0];
		}
		String[] dates = new String[fileList.length];

		for (int i = 0; i < dates.length; i++) {
			dates[i] = sdf.format(new Date(fileList[i].lastModified()));
		}

		return dates;
	}

	public static String[] ConstructColors(Context ctx) {

		String[] fileList = ctx.getFilesDir().list();

		if (fileList == null) {
			return new String[0];
		}

		String[] colorList = new String[fileList.length];

		for (int i = 0; i < fileList.length; i++) {
			colorList[i] = NoteManager.readColorFromNote(ctx, fileList[i]);
			Log.d("RATUL", "COLOR:" + colorList[i]);
		}
		return colorList;

	}

	public static boolean RemoveNote(Context ctx, String title) {
		String rootPath = ctx.getFilesDir().getAbsolutePath();
		return new File(rootPath + "/" + title).delete();
	}
}
