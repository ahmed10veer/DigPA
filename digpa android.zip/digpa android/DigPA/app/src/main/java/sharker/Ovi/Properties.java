package sharker.Ovi;

import android.app.Dialog;
import android.content.Context;
import android.widget.TextView;

public class Properties extends Dialog {

	private TextView title, colorString, size, date;

	public Properties(Context context) {
		super(context);
		setContentView(R.layout.dialog_properties);

		this.title = (TextView) findViewById(R.id.title_properties);
		this.colorString = (TextView) findViewById(R.id.color_properties);
		this.size = (TextView) findViewById(R.id.size_properties);
		this.date = (TextView) findViewById(R.id.date_properties);

	}

	public void setProperties(String title, String colorString, String size,
			String date) {

		this.title.setText(title);
		this.colorString.setText(colorString);
		this.size.setText(size);
		this.date.setText(date);
	}
}
