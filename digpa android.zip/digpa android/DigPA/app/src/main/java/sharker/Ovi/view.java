package sharker.Ovi;

import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

public class view extends AppCompatActivity implements OnClickListener {

	private TextView title, date, content;
	private ScrollView scroll;

	private Dialog dialogAreYouSure;
	private Button yes, no;
	private Properties properties;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view);

		Log.d("RATUL", this.getIntent().getExtras().getString("title"));
		Log.d("RATUL", this.getIntent().getExtras().getString("date"));

		String Title = this.getIntent().getExtras().getString("title"), Date = this
				.getIntent().getExtras().getString("date");

		// initializing
		this.title = (TextView) findViewById(R.id.title_view);
		this.date = (TextView) findViewById(R.id.date_view);
		this.content = (TextView) findViewById(R.id.content_view);
		this.scroll = (ScrollView) findViewById(R.id.scrollView_view);

		this.dialogAreYouSure = new Dialog(this);
		this.dialogAreYouSure.setContentView(R.layout.dialog_are_you_sure);
		this.yes = (Button) this.dialogAreYouSure
				.findViewById(R.id.yes_are_u_sure_dialog);
		this.no = (Button) this.dialogAreYouSure
				.findViewById(R.id.no_are_u_sure_dialog);

		this.properties = new Properties(this);

		// settings
		this.title.setText(Title);
		this.date.setText(Date);
		this.setContent();

		// Listener
		this.yes.setOnClickListener(this);
		this.no.setOnClickListener(this);

	}

	private void setContent() {

		String Title = this.getIntent().getExtras().getString("title");
		String text = NoteManager.readContentFromNote(getApplicationContext(), Title);
		String colorString = NoteManager.readColorFromNote(getApplicationContext(), Title);

		this.content.setText(text);
		this.scroll.setBackgroundColor(Color.parseColor(colorString));

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		boolean val = super.onCreateOptionsMenu(menu);
		;
		MenuInflater mInflater = getMenuInflater();
		mInflater.inflate(R.menu.view_option_menu, menu);

		return val;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub

		if (item.getItemId() == R.id.item_view_option_1) {
			// switch to main
			super.onBackPressed();
		} else if (item.getItemId() == R.id.item_view_option_2) {
			// delete it with a dialog
			// here is only one dialog (for delete option) so no confusion
			this.dialogAreYouSure.setTitle("Delete this note");
			this.dialogAreYouSure.show();
		} else if (item.getItemId() == R.id.item_view_option_3) {
			// show properties

			String title = this.title.getText().toString(), colorString = NoteManager
					.readColorFromNote(getApplicationContext(), this.title.getText().toString()), sizeString = NoteManager
					.readSizeFromNote(getApplicationContext(), title), dateString = NoteManager
					.readDateFromNote(getApplicationContext(), title);

			properties.setProperties(this.title.getText().toString(),
					colorString, sizeString, dateString);
			properties.setTitle("Properties - " + title);
			properties.show();
		}

		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.equals(this.yes)) {
			// yess pressed for delete option only
			NoteManager.RemoveNote(getApplicationContext(), this.title.getText().toString());
			this.dialogAreYouSure.cancel();
			onBackPressed();
		} else if (v.equals(this.no)) {
			// no button pressed for delete option only
			this.dialogAreYouSure.cancel();
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		this.finish();
		super.onPause();
	}

}
